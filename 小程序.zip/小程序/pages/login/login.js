Page({
  data: {
    username: '',
    password: ''
  },

  onUsernameInput(e) {
    this.setData({ username: e.detail.value });
  },

  onPasswordInput(e) {
    this.setData({ password: e.detail.value });
  },

  onLogin() {
    const { username, password } = this.data;
    if (username === '1' && password === '123') {
      wx.setStorageSync('isAdmin', true);
      wx.showToast({ title: '登录成功' });
      wx.redirectTo({ url: '/pages/index/index' });
    } else {
      wx.showToast({ title: '账号或密码错误', icon: 'none' });
    }
  }
});
