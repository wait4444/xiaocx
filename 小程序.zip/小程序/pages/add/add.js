Page({
  data: {
    name: '',
    manager: '',
    photo: '',
    video: ''
  },

  onNameInput(e) {
    this.setData({ name: e.detail.value });
  },

  onManagerInput(e) {
    this.setData({ manager: e.detail.value });
  },

  choosePhoto() {
    wx.chooseImage({
      count: 1,
      success: res => {
        this.setData({ photo: res.tempFilePaths[0] });
      }
    });
  },

  chooseVideo() {
    wx.chooseVideo({
      success: res => {
        this.setData({ video: res.tempFilePath });
      }
    });
  },

  submit() {
    const { name, manager, photo, video } = this.data;
    if (!name || !manager || !photo || !video) {
      wx.showToast({ title: '请填写完整信息', icon: 'none' });
      return;
    }

    let departments = wx.getStorageSync('departments') || [];
    departments.push({ name, manager, photo, video });
    wx.setStorageSync('departments', departments);
    wx.showToast({ title: '添加成功' });
    wx.redirectTo({ url: '/pages/index/index' });
  }
});
