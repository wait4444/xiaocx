Page({
  data: {
    departments: [],
    isAdmin: false
  },

  onShow() {
    const departments = wx.getStorageSync('departments') || [];
    const isAdmin = wx.getStorageSync('isAdmin') || false;
    this.setData({ departments, isAdmin });
  },

  goToLogin() {
    wx.navigateTo({ url: '/pages/login/login' });
  },

  goToAdd() {
    wx.navigateTo({ url: '/pages/add/add' });
  },

  onDelete() {
    let departments = wx.getStorageSync('departments') || [];
    if (departments.length > 0) {
      departments.pop();
      wx.setStorageSync('departments', departments);
      this.setData({ departments });
      wx.showToast({ title: '已删除' });
    } else {
      wx.showToast({ title: '无可删除项', icon: 'none' });
    }
  },

  logout() {
    wx.setStorageSync('isAdmin', false);
    this.setData({ isAdmin: false });
  }
});
